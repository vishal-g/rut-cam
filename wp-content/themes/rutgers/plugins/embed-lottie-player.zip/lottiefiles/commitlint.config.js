/**
 * Copyright 2021 Design Barn Inc.
 */

module.exports = { extends: ['@commitlint/config-conventional'] };
