<?php

namespace DeliciousBrains\WPMDBMST;

class MultisiteToolsAddon {
    //Silence is golden.
}
