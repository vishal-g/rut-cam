<?php

namespace DeliciousBrains\WPMDBTP;

class ThemePluginFilesAddon {
    //Silence is golden.
}
