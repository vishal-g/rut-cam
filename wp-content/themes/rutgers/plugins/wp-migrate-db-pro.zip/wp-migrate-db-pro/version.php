<?php
$GLOBALS['wpmdb_meta']['wp-migrate-db-pro']['version'] = '2.3.4';
