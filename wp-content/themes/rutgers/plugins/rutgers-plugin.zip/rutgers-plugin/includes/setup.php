<?php

function tbones_setup_theme()
{
    add_image_size('carouselSlider', 500, 416, true);
}