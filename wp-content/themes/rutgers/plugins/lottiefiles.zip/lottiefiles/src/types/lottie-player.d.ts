/**
 * Copyright 2022 Design Barn Inc.
 */

declare namespace JSX {
  interface IntrinsicElements {
    'dotlottie-player': unknown;
    'lottie-player': unknown;
  }
}
